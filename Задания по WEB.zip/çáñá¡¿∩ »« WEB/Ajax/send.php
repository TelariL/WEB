<?php
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['username']) || !isset($data['message'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Недопустимые данные']);
    exit;
}

$username = strip_tags(trim($data['username']));
$message = strip_tags(trim($data['message']));

if (!$username || !$message) {
    http_response_code(400);
    echo json_encode(['error' => 'Имя и сообщение обязательны']);
    exit;
}

$file = 'messages.json';
$messages = [];

if (file_exists($file)) {
    $json = file_get_contents($file);
    $messages = json_decode($json, true) ?: [];
}

$messages[] = ['username' => $username, 'text' => $message];

// Сохраняем обновлённый список
file_put_contents($file, json_encode($messages, JSON_PRETTY_PRINT));

echo json_encode(['status' => 'ok']);
