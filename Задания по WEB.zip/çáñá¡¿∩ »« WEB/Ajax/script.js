function createRequestPool(limit) {
      let queue = [];
      let active = 0;

      const next = () => {
        if (active >= limit || queue.length === 0) return;
        const { task, resolve, reject } = queue.shift();
        active++;
        task()
          .then(resolve)
          .catch(reject)
          .finally(() => {
            active--;
            next();
          });
      };

      return function enqueue(task) {
        return new Promise((resolve, reject) => {
          queue.push({ task, resolve, reject });
          next();
        });
      };
    }

    // === Ограничим количество одновременных запросов к серверу ===
    const requestPool = createRequestPool(2); // максимум 2 запроса одновременно

    async function loadMessages() {
      try {
        const res = await fetch('messages.json?nocache=' + Date.now());
        const data = await res.json();
        const chatBox = document.getElementById('chat-box');
        chatBox.innerHTML = data.map(msg =>
          `<p><strong>${msg.username}:</strong> ${msg.text}</p>`
        ).join('');
        console.log('Загруженные сообщения:', data);
        chatBox.scrollTop = chatBox.scrollHeight;
      } catch (err) {
        document.getElementById('error').textContent = "Ошибка загрузки сообщений";
      }
    }

    // Обёртка, которая добавляет loadMessages в очередь
    function loadMessagesThrottled() {
      return requestPool(() => loadMessages());
    }

    // === Отправка сообщений ===
    document.getElementById('chat-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('username').value;
      const message = document.getElementById('message').value;
      const errorElem = document.getElementById('error');

      try {
        const res = await fetch('send.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, message })
        });

        if (!res.ok) throw new Error('Ошибка при отправке');

        await loadMessagesThrottled();
        document.getElementById('message').value = '';
        errorElem.textContent = '';
      } catch (err) {
        errorElem.textContent = err.message;
      }
    });

    

    // === Периодическая загрузка сообщений ===
    setInterval(loadMessagesThrottled, 3000);
    loadMessagesThrottled();