const output = document.getElementById('output');

    function delayTask(name, time) {
        return () => new Promise(resolve => {
                setTimeout(() => {
                    output.textContent += `${name} завершена через ${time}мс\n`;
                    resolve();
                }, time);
        });
    }

    function promisePool(tasks, poolLimit) {
        let i = 0;

        const executor = async () => {
            while (i < tasks.length) {
            const taskIndex = i++;
            await tasks[taskIndex]();
            }
        };

        const pool = [];
        for (let j = 0; j < Math.min(poolLimit, tasks.length); j++) {
            pool.push(executor());
        }

        return Promise.all(pool);
    }

    function runPool() {
        output.textContent = "Запуск задач...\n";

        const tasks = [
            delayTask("Задача 1", 1000),
            delayTask("Задача 2", 600),
            delayTask("Задача 3", 300),
            delayTask("Задача 4", 700),
            delayTask("Задача 5", 500)
        ];

        promisePool(tasks, 1).then(() => {
            output.textContent += "✅ Все задачи завершены\n";
        });
    }