<?php
// Получение данных из формы
$user = [
    "Name"    => trim($_POST["Name"] ?? ''),
    "Address" => trim($_POST["Address"] ?? ''),
    "Phone"   => trim($_POST["Phone"] ?? ''),
    "Mail"    => trim($_POST["Mail"] ?? '')
];

// Валидация
function isValidPhone($phone) {
    return preg_match('/^\+7\s?\(?\d{3}\)?[\s-]?\d{3}-?\d{2}-?\d{2}$/', $phone);
}

function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Вывод
echo "<h3>Результат:</h3>";
echo "<table>
        <thead>
            <tr><th>Элемент</th><th>Значение</th></tr>
        </thead>
        <tbody>";

foreach ($user as $key => $value) {
    echo "<tr><td>$key</td><td>";

    if (empty($value)) {
        echo "<span class='error'>❌ Значение не указано</span>";
    } elseif ($key === "Phone" && !isValidPhone($value)) {
        echo "<span class='error'>❌ Неверный формат телефона</span>";
    } elseif ($key === "Mail" && !isValidEmail($value)) {
        echo "<span class='error'>❌ Неверный формат email</span>";
    } else {
        echo htmlspecialchars($value);
    }

    echo "</td></tr>";
}

echo "</tbody></table>";
?>
