<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Форма пользователя</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }
        form {
            margin-bottom: 30px;
        }
        input[type="text"], input[type="email"] {
            padding: 8px;
            width: 300px;
            margin-bottom: 10px;
            display: block;
        }
        input[type="submit"] {
            padding: 10px 20px;
        }
        table {
            border-collapse: collapse;
            width: 60%;
            margin-top: 20px;
        }
        th, td {
            padding: 10px 15px;
            border: 1px solid #ccc;
        }
        th {
            background-color: #f3f3f3;
            text-align: left;
        }
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Введите данные пользователя</h2>

<form action="index.php" method="post">
    <label>Имя:
        <input type="text" name="Name" required>
    </label>
    <label>Адрес:
        <input type="text" name="Address" required>
    </label>
    <label>Телефон:
        <input type="text" name="Phone" placeholder="+7 (123) 456-78-90" required>
    </label>
    <label>Email:
        <input type="email" name="Mail" required>
    </label>
    <input type="submit" value="Отправить">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    include 'user-data.php';
}
?>

</body>
</html>
