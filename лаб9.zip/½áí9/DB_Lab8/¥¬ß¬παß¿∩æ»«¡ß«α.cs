﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class ЭкскурсияСпонсор : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Aid2 = "";
        public string Aotch = "";

        public ЭкскурсияСпонсор(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void экскурсияСпонсор_Load(object sender, EventArgs e)
        {
            textBox1.Text = Aotch;

            if (Aid != "")
            {
                PG.PopulateFKgrid("Экскурсия", dataGridView1, "id-экскурсии", Aid);
            }
            if (Aid2 != "")
            {
                PG.PopulateFKgrid("Спонсор", dataGridView2, "id-спонсор", Aid2);
            }
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string otch = textBox1.Text;

            if ((Aid != "") && (Aid2 != "") && (otch != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"PatientReceptionLog_Patients\" " +
                        "(\"DetectionID\", \"RegistrationID\", \"Analysis\") " +
                        "VALUES ('" + Aid + "','" + Aid2 + "','" + otch + "');";

                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Экскурсия";
            fk.view = true;
            fk.sel_id_name = "id-экскурсии";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid = fk.sel_id;
                PG.PopulateFKgrid("Экскурсия", dataGridView1, "id-экскурсии", Aid);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Спонсор";
            fk.view = true;
            fk.sel_id_name = "id-спонсор";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Спонсор", dataGridView2, "id-спонсор", Aid2);
            }
        }
    }
}
