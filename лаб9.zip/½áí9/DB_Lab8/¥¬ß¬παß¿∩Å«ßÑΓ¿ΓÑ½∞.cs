﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class ЭкскурсияПосетитель : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Aid2 = "";
        public string Aotz = "";
        public string Adata = "";

        public ЭкскурсияПосетитель(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void экскурсияПосетитель_Load(object sender, EventArgs e)
        {
            textBox1.Text = Aotz;
            textBox2.Text = Adata;

            if (Aid != "")
            {
                PG.PopulateFKgrid("Экскурсия", dataGridView1, "id-экскурсии", Aid);
            }
            if (Aid2 != "")
            {
                PG.PopulateFKgrid("Посетитель", dataGridView2, "id-посетитель", Aid2);
            }
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string otz = textBox1.Text;
            string data = textBox2.Text;

            if ((Aid != "") && (Aid2 != "") && (otz != "") && (data != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"ЭкскурсияПосетитель\" " +
                        "(\"id-экскурсии\", \"id-посетитель\", \"Отзывы\", \"Дата посещения\") " +
                        "VALUES ('" + Aid + "','" + Aid2 + "','" + otz + "','" + data + "');";

                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Экскурсия";
            fk.view = true;
            fk.sel_id_name = "id-экскурсии";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid = fk.sel_id;
                PG.PopulateFKgrid("Экскурсия", dataGridView1, "id-экскурсии", Aid);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Посетитель";
            fk.view = true;
            fk.sel_id_name = "id-посетитель";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Посетитель", dataGridView2, "id-посетитель", Aid2);
            }
        }
    }
}
