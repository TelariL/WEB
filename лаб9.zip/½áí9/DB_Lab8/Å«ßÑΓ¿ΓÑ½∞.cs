﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class Посетитель : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Aname = "";
        public string Anumber = "";

        public Посетитель(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void посетитель_Load(object sender, EventArgs e)
        {
            textBox1.Text = Aname;
            textBox2.Text = Anumber;
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string number = textBox2.Text;

            if ((name != "") && (number != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Посетитель\" " +
                        "(\"ФИО\", \"Номер телефона\") " +
                        "VALUES ('" + name + "','" + number + "');";
                else
                    parent.tcom = "UPDATE \"Посетитель\" " +
                        "SET \"ФИО\" = '" + name
                        + "', \"Номер телефона\" = '" + number
                        + "' WHERE \"id-посетитель\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}
