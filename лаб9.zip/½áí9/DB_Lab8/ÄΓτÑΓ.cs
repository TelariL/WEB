﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab8
{
    public partial class Отчет : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Anzakaza = "";
        public string Adata = "";
        public string Aid2 = "";

        public Отчет(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void отчет_Load(object sender, EventArgs e)
        {
            textBox1.Text = Anzakaza;
            textBox3.Text = Adata;
            if (Aid2 != "")
            {
                PG.PopulateFKgrid("Менеджер по работе с клиентами", dataGridView1, "ФИО", Aid2);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Anzakaza = textBox1.Text;
            string Adata = textBox3.Text;

            if ((Anzakaza != "") && (Aid2 != "") && (Adata != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Отчет\" " +
                        "(\"Номер заказа\", \"ФИО\", \"Дата создания\") " +
                        "VALUES ('" + Anzakaza + "','" + Aid2 + "','" + Adata + "');";
                else
                    parent.tcom = "UPDATE \"Отчет\" " +
                        "SET \"Номер заказа\" = '" + Anzakaza
                        + "', \"ФИО\" = '" + Aid2
                        + "', \"Дата создания\" = '" + Adata
                        + "' WHERE \"Номер отчета\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Менеджер по работе с клиентами";
            fk.view = true;
            fk.sel_id_name = "ФИО";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Менеджер по работе с клиентами", dataGridView1, "ФИО", Aid2);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
