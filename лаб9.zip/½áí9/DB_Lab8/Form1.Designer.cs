﻿using System.Drawing;
using System.Windows.Forms;
using System;

namespace postgr2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.экспонатToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.стендToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.экскурсияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.спонсорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.местоПроведенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.посетительToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сувенирToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.стендистToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.экскурсияПосетительToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.экскурсияСпонсорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.экспонатСтендToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.отзывыоПосещенииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.спонсорскийОтчетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.описаниеПродукцииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.менеджерПоРаботеСКлиентамиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заказToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(4, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(86, 20);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(4, 55);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(86, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(4, 81);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(86, 20);
            this.textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(4, 106);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(86, 20);
            this.textBox4.TabIndex = 3;
            this.textBox4.TabStop = false;
            this.textBox4.UseSystemPasswordChar = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(4, 131);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(86, 20);
            this.textBox5.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(95, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "host";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(95, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "port";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(95, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "user";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(95, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "pass";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(95, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "DB";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(371, 24);
            this.menuStrip1.TabIndex = 15;
            this.menuStrip1.Text = "Данные";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.экспонатToolStripMenuItem,
            this.стендToolStripMenuItem,
            this.экскурсияToolStripMenuItem,
            this.спонсорToolStripMenuItem,
            this.менеджерПоРаботеСКлиентамиToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(94, 20);
            this.toolStripMenuItem1.Text = "Справочники";
            // 
            // экспонатToolStripMenuItem
            // 
            this.экспонатToolStripMenuItem.Name = "экспонатToolStripMenuItem";
            this.экспонатToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.экспонатToolStripMenuItem.Text = "Экспонат";
            this.экспонатToolStripMenuItem.Click += new System.EventHandler(this.экспонатToolStripMenuItem_Click);
            // 
            // стендToolStripMenuItem
            // 
            this.стендToolStripMenuItem.Name = "стендToolStripMenuItem";
            this.стендToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.стендToolStripMenuItem.Text = "Стенд";
            this.стендToolStripMenuItem.Click += new System.EventHandler(this.стендToolStripMenuItem_Click);
            // 
            // экскурсияToolStripMenuItem
            // 
            this.экскурсияToolStripMenuItem.Name = "экскурсияToolStripMenuItem";
            this.экскурсияToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.экскурсияToolStripMenuItem.Text = "Экскурсия";
            this.экскурсияToolStripMenuItem.Click += new System.EventHandler(this.экскурсияToolStripMenuItem_Click);
            // 
            // спонсорToolStripMenuItem
            // 
            this.спонсорToolStripMenuItem.Name = "спонсорToolStripMenuItem";
            this.спонсорToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.спонсорToolStripMenuItem.Text = "Спонсор";
            this.спонсорToolStripMenuItem.Click += new System.EventHandler(this.спонсорToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.местоПроведенияToolStripMenuItem,
            this.посетительToolStripMenuItem,
            this.сувенирToolStripMenuItem,
            this.стендистToolStripMenuItem,
            this.экскурсияПосетительToolStripMenuItem,
            this.экскурсияСпонсорToolStripMenuItem,
            this.экспонатСтендToolStripMenuItem,
            this.отчетToolStripMenuItem,
            this.заказToolStripMenuItem,
            this.клиентToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(62, 20);
            this.toolStripMenuItem2.Text = "Данные";
            // 
            // местоПроведенияToolStripMenuItem
            // 
            this.местоПроведенияToolStripMenuItem.Name = "местоПроведенияToolStripMenuItem";
            this.местоПроведенияToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.местоПроведенияToolStripMenuItem.Text = "Место проведения";
            this.местоПроведенияToolStripMenuItem.Click += new System.EventHandler(this.местоПроведенияToolStripMenuItem_Click);
            // 
            // посетительToolStripMenuItem
            // 
            this.посетительToolStripMenuItem.Name = "посетительToolStripMenuItem";
            this.посетительToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.посетительToolStripMenuItem.Text = "Посетитель";
            this.посетительToolStripMenuItem.Click += new System.EventHandler(this.посетительToolStripMenuItem_Click);
            // 
            // сувенирToolStripMenuItem
            // 
            this.сувенирToolStripMenuItem.Name = "сувенирToolStripMenuItem";
            this.сувенирToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.сувенирToolStripMenuItem.Text = "Сувенир";
            this.сувенирToolStripMenuItem.Click += new System.EventHandler(this.сувенирToolStripMenuItem_Click);
            // 
            // стендистToolStripMenuItem
            // 
            this.стендистToolStripMenuItem.Name = "стендистToolStripMenuItem";
            this.стендистToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.стендистToolStripMenuItem.Text = "Стендист";
            this.стендистToolStripMenuItem.Click += new System.EventHandler(this.стендистToolStripMenuItem_Click);
            // 
            // экскурсияПосетительToolStripMenuItem
            // 
            this.экскурсияПосетительToolStripMenuItem.Name = "экскурсияПосетительToolStripMenuItem";
            this.экскурсияПосетительToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.экскурсияПосетительToolStripMenuItem.Text = "ЭкскурсияПосетитель";
            this.экскурсияПосетительToolStripMenuItem.Click += new System.EventHandler(this.экскурсияПосетительToolStripMenuItem_Click);
            // 
            // экскурсияСпонсорToolStripMenuItem
            // 
            this.экскурсияСпонсорToolStripMenuItem.Name = "экскурсияСпонсорToolStripMenuItem";
            this.экскурсияСпонсорToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.экскурсияСпонсорToolStripMenuItem.Text = "ЭкскурсияСпонсор";
            this.экскурсияСпонсорToolStripMenuItem.Click += new System.EventHandler(this.экскурсияСпонсорToolStripMenuItem_Click_1);
            // 
            // экспонатСтендToolStripMenuItem
            // 
            this.экспонатСтендToolStripMenuItem.Name = "экспонатСтендToolStripMenuItem";
            this.экспонатСтендToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.экспонатСтендToolStripMenuItem.Text = "ЭкспонатСтенд";
            this.экспонатСтендToolStripMenuItem.Click += new System.EventHandler(this.экспонатСтендToolStripMenuItem_Click_1);
            // 
            // отчетToolStripMenuItem
            // 
            this.отчетToolStripMenuItem.Name = "отчетToolStripMenuItem";
            this.отчетToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.отчетToolStripMenuItem.Text = "Отчет";
            this.отчетToolStripMenuItem.Click += new System.EventHandler(this.отчетToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отзывыоПосещенииToolStripMenuItem,
            this.спонсорскийОтчетToolStripMenuItem,
            this.описаниеПродукцииToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(60, 20);
            this.toolStripMenuItem3.Text = "Отчеты";
            // 
            // отзывыоПосещенииToolStripMenuItem
            // 
            this.отзывыоПосещенииToolStripMenuItem.Name = "отзывыоПосещенииToolStripMenuItem";
            this.отзывыоПосещенииToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.отзывыоПосещенииToolStripMenuItem.Text = "Отзывы о посещении";
            this.отзывыоПосещенииToolStripMenuItem.Click += new System.EventHandler(this.отзывыоПосещенииToolStripMenuItem_Click);
            // 
            // спонсорскийОтчетToolStripMenuItem
            // 
            this.спонсорскийОтчетToolStripMenuItem.Name = "спонсорскийОтчетToolStripMenuItem";
            this.спонсорскийОтчетToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.спонсорскийОтчетToolStripMenuItem.Text = "Спонсорский отчет";
            this.спонсорскийОтчетToolStripMenuItem.Click += new System.EventHandler(this.спонсорскийОтчетToolStripMenuItem_Click);
            // 
            // описаниеПродукцииToolStripMenuItem
            // 
            this.описаниеПродукцииToolStripMenuItem.Name = "описаниеПродукцииToolStripMenuItem";
            this.описаниеПродукцииToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.описаниеПродукцииToolStripMenuItem.Text = "Описание продукции";
            this.описаниеПродукцииToolStripMenuItem.Click += new System.EventHandler(this.описаниеПродукцииToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(94, 20);
            this.toolStripMenuItem4.Text = "О программе";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(54, 20);
            this.toolStripMenuItem5.Text = "Выход";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // менеджерПоРаботеСКлиентамиToolStripMenuItem
            // 
            this.менеджерПоРаботеСКлиентамиToolStripMenuItem.Name = "менеджерПоРаботеСКлиентамиToolStripMenuItem";
            this.менеджерПоРаботеСКлиентамиToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.менеджерПоРаботеСКлиентамиToolStripMenuItem.Text = "Менеджер по работе с клиентами";
            this.менеджерПоРаботеСКлиентамиToolStripMenuItem.Click += new System.EventHandler(this.менеджерПоРаботеСКлиентамиToolStripMenuItem_Click);
            // 
            // заказToolStripMenuItem
            // 
            this.заказToolStripMenuItem.Name = "заказToolStripMenuItem";
            this.заказToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.заказToolStripMenuItem.Text = "Заказ";
            this.заказToolStripMenuItem.Click += new System.EventHandler(this.заказToolStripMenuItem_Click);
            // 
            // клиентToolStripMenuItem
            // 
            this.клиентToolStripMenuItem.Name = "клиентToolStripMenuItem";
            this.клиентToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.клиентToolStripMenuItem.Text = "Клиент";
            this.клиентToolStripMenuItem.Click += new System.EventHandler(this.клиентToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 183);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "PostreSQL Connect";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem toolStripMenuItem4;
        private ToolStripMenuItem toolStripMenuItem5;
        private ToolStripMenuItem экспонатToolStripMenuItem;
        private ToolStripMenuItem стендToolStripMenuItem;
        private ToolStripMenuItem экскурсияToolStripMenuItem;
        private ToolStripMenuItem местоПроведенияToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem посетительToolStripMenuItem;
        private ToolStripMenuItem сувенирToolStripMenuItem;
        private ToolStripMenuItem стендистToolStripMenuItem;
        private ToolStripMenuItem отзывыоПосещенииToolStripMenuItem;
        private ToolStripMenuItem медицинскиеРегистраторыToolStripMenuItem;
        private ToolStripMenuItem спонсорскийОтчетToolStripMenuItem;
        private ToolStripMenuItem описаниеПродукцииToolStripMenuItem;
        private ToolStripMenuItem спонсорToolStripMenuItem;
        private ToolStripMenuItem экскурсияПосетительToolStripMenuItem;
        private ToolStripMenuItem экскурсияСпонсорToolStripMenuItem;
        private ToolStripMenuItem экспонатСтендToolStripMenuItem;
        private ToolStripMenuItem отчетToolStripMenuItem;
        private ToolStripMenuItem менеджерПоРаботеСКлиентамиToolStripMenuItem;
        private ToolStripMenuItem заказToolStripMenuItem;
        private ToolStripMenuItem клиентToolStripMenuItem;
    }
}
