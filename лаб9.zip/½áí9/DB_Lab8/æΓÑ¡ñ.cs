﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class Стенд : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Asteal = "";
        public string Arazmer = "";
        public string Aid2 = "";
        public string Aid3 = "";

        public Стенд(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void стенд_Load(object sender, EventArgs e)
        {
            textBox1.Text = Asteal;
            textBox2.Text = Arazmer;
            if (Aid2 != "")
            {
                PG.PopulateFKgrid("Стендист", dataGridView1, "id-стендиста", Aid2);
            }
            if (Aid3 != "")
            {
                PG.PopulateFKgrid("Экскурсия", dataGridView2, "id-экскурсия", Aid3);
            }
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string steal = textBox1.Text;
            string razmer = textBox2.Text;

            if ((Aid2 != "") && (Aid3 != "") && (steal != "") && (razmer != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Стенд\" " +
                        "(\"id-стендиста\", \"id-экскурсия\", \"Стиль\", \"Размер\") " +
                        "VALUES ('" + Aid2 + "','" + Aid3 + "','" + steal + "', '" + razmer + "');";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Стендист";
            fk.view = true;
            fk.sel_id_name = "id-стендиста";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Стендист", dataGridView1, "id-стендиста", Aid2);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Экскурсия";
            fk.view = true;
            fk.sel_id_name = "id-экскурсия";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid3 = fk.sel_id;
                PG.PopulateFKgrid("Экскурсия", dataGridView2, "id-экскурсия", Aid3);
            }
        }
    }
}
