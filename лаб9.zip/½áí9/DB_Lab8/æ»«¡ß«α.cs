﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class Спонсор : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Asum = "";
        public string Aval = "";
        public string Aname = "";

        public Спонсор(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void спонсор_Load(object sender, EventArgs e)
        {
            textBox1.Text = Asum;
            textBox2.Text = Aname;
            textBox3.Text = Aval;
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sum = textBox1.Text;
            string name = textBox2.Text;
            string val = textBox3.Text;


            if ((sum != "") && (val != "") && (name != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Спонсор\" " +
                        "(\"Сумма\", \"ФИО\", \"Валюта\") " +
                        "VALUES ('" + sum + "','" + name + "','" + val + "');";
                else
                    parent.tcom = "UPDATE \"Спонсор\" " +
                        "SET \"Сумма\" = '" + sum
                        + "', \"ФИО\" = '" + name
                        + "', \"Валюта\" = '" + val
                        + "' WHERE \"id-спонсора\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}
