﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Lab8
{
    public partial class Менеджерпоработесклиентами : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Astazh = "";
        public string Adata = "";
        public string Aid2 = "";

        public Менеджерпоработесклиентами(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void менеджерпоработесклиентами_Load(object sender, EventArgs e)
        {
            textBox1.Text = Astazh;
            textBox3.Text = Adata;
            if (Aid2 != "")
            {
                PG.PopulateFKgrid("Заказ", dataGridView1, "Номер заказа", Aid2);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Astazh = textBox1.Text;
            string Adata = textBox3.Text;

            if ((Astazh != "") && (Aid2 != "") && (Adata != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Менеджер по работе с клиентами\" " +
                        "(\"Стаж работы\", \"Номер заказа\", \"Дата рождения\") " +
                        "VALUES ('" + Astazh + "','" + Aid2 + "','" + Adata + "');";
                else
                    parent.tcom = "UPDATE \"Менеджер по работе с клиентамит\" " +
                        "SET \"Стаж работы\" = '" + Astazh
                        + "', \"Номер заказа\" = '" + Aid2
                        + "', \"Дата рождения\" = '" + Adata
                        + "' WHERE \"Номер отчета\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Заказ";
            fk.view = true;
            fk.sel_id_name = "Номер заказа";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Заказ", dataGridView1, "Номер заказа", Aid2);
            }
        }
    }
}
