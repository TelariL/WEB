﻿using DB_Lab8;
using DB_Lab9;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace postgr2
{
    public partial class CRUD : Form
    {
        private Form prevform;
        public bool view = false;
        public bool allow_upd = true;
        public string table = "";
        public string pk_name = "";
        public string pk_name2 = "";
        public string pk_name3 = "";
        public string pk_name4 = "";
        public int n = 5;

        public string tcom = "";

        public string sel_id_name = "";
        public string sel_id = "";

        private int sz = 0;
        private int pages = 0;
        public CRUD(Form prevform)
        {
            InitializeComponent();
            this.prevform = prevform;
        }

        private void resize()
        {
            if (table != "")
            {
                sz = (int)PG.Select_size(table);
                pages = sz / n + (sz % n == 0 ? 0 : 1);
            }
        }

        private void reload_view()
        {
            int pg = Convert.ToInt32(textBox1.Text);
            if (table != "") PG.Populate_grid(table, dataGridView1, n, pg - 1);
        }

        private void CRUD_Load(object sender, EventArgs e)
        {
            resize();
            reload_view();
            if (view)
            {
                button1.Hide();
                button2.Hide();
                button3.Hide();
            }
            if (!allow_upd) button2.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int pg = Convert.ToInt32(textBox1.Text);
            if (pg > 1) textBox1.Text = (pg - 1).ToString();
            reload_view();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int pg = Convert.ToInt32(textBox1.Text);
            if (pg < pages) textBox1.Text = (pg + 1).ToString();
            reload_view();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int pg;
            try
            {
                pg = Convert.ToInt32(textBox1.Text);
                if ((pg < 1) || (pg > pages)) throw new Exception("pg");
            }
            catch (Exception)
            {
                pg = 1;
                textBox1.Text = "1";
            }
            textBox1.Text = pg.ToString();
            reload_view();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ((table != "") && (pk_name != "") && (pk_name2 != "") && (pk_name3 != ""))
            {
                foreach (DataGridViewRow x in dataGridView1.SelectedRows)
                    PG.Delete3(table, pk_name, (string)x.Cells[pk_name].Value,
                        pk_name2, (string)x.Cells[pk_name2].Value,
                        pk_name3, (string)x.Cells[pk_name3].Value);
            }
            if ((table != "") && (pk_name != "") && (pk_name2 != ""))
            {
                foreach (DataGridViewRow x in dataGridView1.SelectedRows)
                    PG.Delete2(table, pk_name, (string)x.Cells[pk_name].Value,
                        pk_name2, (string)x.Cells[pk_name2].Value);
            }
            else if ((table != "") && (pk_name != ""))
            {
                foreach (DataGridViewRow x in dataGridView1.SelectedRows)
                    PG.Delete(table, pk_name, (string)x.Cells[pk_name].Value);
            }
            resize();
            reload_view();
            if (dataGridView1.Rows.Count == 0)
            {
                int pg = Convert.ToInt32(textBox1.Text);
                if (pg > 1) textBox1.Text = (pg - 1).ToString();
                reload_view();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (table == "Место проведения")
            {
                МестоПроведения s = new МестоПроведения(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Отчет")
            {
                Отчет s = new Отчет(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Заказ")
            {
                Заказ s = new Заказ(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Менеджер по работе с клиентами")
            {
                Менеджерпоработесклиентами s = new Менеджерпоработесклиентами(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Клиент")
            {
                Клиент s = new Клиент(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Посетитель")
            {
                Посетитель s = new Посетитель(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Спонсор")
            {
                Спонсор s = new Спонсор(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Стенд")
            {
                Стенд s = new Стенд(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Стендист")
            {
                Стендист s = new Стендист(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Суенир")
            {
                Сувенир s = new Сувенир(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Экскурсия")
            {
                Экскурсия s = new Экскурсия(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "ЭкскурсияПосетитель")
            {
                ЭкскурсияПосетитель s = new ЭкскурсияПосетитель(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "ЭкскурсияСпонсор")
            {
                ЭкскурсияСпонсор s = new ЭкскурсияСпонсор(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "ЭкспонатСтенд")
            {
                ЭкспонатСтенд s = new ЭкспонатСтенд(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
            if (table == "Экспонат")
            {
                Экспонат s = new Экспонат(this);
                s.parent = this;
                s.empty_start = true;
                DialogResult d = s.ShowDialog();
                if (d == DialogResult.OK)
                {
                    PG.SendCU(tcom);
                    resize();
                    reload_view();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 0)
            {
                if (table == "Место проведения")
                {
                    МестоПроведения s = new МестоПроведения(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id_место"].Value;
                    s.Astrana = (string)dataGridView1.SelectedRows[0].Cells["Страна"].Value;
                    s.Agorod = (string)dataGridView1.SelectedRows[0].Cells["Город"].Value;
                    s.Aadres = (string)dataGridView1.SelectedRows[0].Cells["Адрес"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Отчет")
                {
                    Отчет s = new Отчет(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["Номер отчета"].Value;
                    s.Anzakaza = (string)dataGridView1.SelectedRows[0].Cells["Номер заказа"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["ФИО"].Value;
                    s.Adata = (string)dataGridView1.SelectedRows[0].Cells["Дата создания"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Менеджерпоработесклиентами")
                {
                    Менеджерпоработесклиентами s = new Менеджерпоработесклиентами(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["ФИО"].Value;
                    s.Astazh = (string)dataGridView1.SelectedRows[0].Cells["Стаж работы"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["Номер заказа"].Value;
                    s.Adata = (string)dataGridView1.SelectedRows[0].Cells["Дата рождения"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Заказ")
                {
                    Заказ s = new Заказ(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["Номер заказа"].Value;
                    s.Adan = (string)dataGridView1.SelectedRows[0].Cells["Данные об объекте"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["ФИО"].Value;
                    s.Aid3 = (string)dataGridView1.SelectedRows[0].Cells["ID организации"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Клиент")
                {
                    Клиент s = new Клиент(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["ID клиента"].Value;
                    s.Afio = (string)dataGridView1.SelectedRows[0].Cells["ФИО клиента"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Посетитель")
                {
                    Посетитель s = new Посетитель(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id-посетитель"].Value;
                    s.Aname = (string)dataGridView1.SelectedRows[0].Cells["ФИО"].Value;
                    s.Anumber = (string)dataGridView1.SelectedRows[0].Cells["Номер телефона"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Спонсор")
                {
                    Спонсор s = new Спонсор(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id-спонсора"].Value;
                    s.Asum = (string)dataGridView1.SelectedRows[0].Cells["Сумма"].Value;
                    s.Aname = (string)dataGridView1.SelectedRows[0].Cells["ФИО"].Value;
                    s.Aval = (string)dataGridView1.SelectedRows[0].Cells["Валюта"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Стенд")
                {
                    Стенд s = new Стенд(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["Номер стенда"].Value;
                    s.Asteal = (string)dataGridView1.SelectedRows[0].Cells["Стиль"].Value;
                    s.Arazmer = (string)dataGridView1.SelectedRows[0].Cells["Размер"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["id-стендиста"].Value;
                    s.Aid3 = (string)dataGridView1.SelectedRows[0].Cells["id-экскурсия"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Сувенир")
                {
                    Сувенир s = new Сувенир(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id-сувенир"].Value;
                    s.Aform = (string)dataGridView1.SelectedRows[0].Cells["Форма"].Value;
                    s.Amat = (string)dataGridView1.SelectedRows[0].Cells["Материал"].Value;
                    s.Atema = (string)dataGridView1.SelectedRows[0].Cells["Тематика"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["id-место"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Экскурсия")
                {
                    Экскурсия s = new Экскурсия(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id-экскурсии"].Value;
                    s.Astoim = (string)dataGridView1.SelectedRows[0].Cells["Стоимость"].Value;
                    s.Atema = (string)dataGridView1.SelectedRows[0].Cells["Тема"].Value;
                    s.Adlit = (string)dataGridView1.SelectedRows[0].Cells["Длительность"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["id-место"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "ЭкскурсияПосетитель")
                {
                    ЭкскурсияПосетитель s = new ЭкскурсияПосетитель(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id-экскурсии"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["id-посетитель"].Value;
                    s.Aotz = (string)dataGridView1.SelectedRows[0].Cells["Отзывы"].Value;
                    s.Adata = (string)dataGridView1.SelectedRows[0].Cells["Дата посещения"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "ЭкскурсияСпонсор")
                {
                    ЭкскурсияСпонсор s = new ЭкскурсияСпонсор(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id-экскурсии"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["id-спонсор"].Value;
                    s.Aotch = (string)dataGridView1.SelectedRows[0].Cells["Отчет Экскурсии"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Экспонат")
                {
                    Экспонат s = new Экспонат(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id-экспонат"].Value;
                    s.Aname = (string)dataGridView1.SelectedRows[0].Cells["название"].Value;
                    s.Aavtor = (string)dataGridView1.SelectedRows[0].Cells["автор"].Value;
                    s.Amuch = (string)dataGridView1.SelectedRows[0].Cells["цена"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "ЭкспонатСтенд")
                {
                    ЭкспонатСтенд s = new ЭкспонатСтенд(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["Номер стенда"].Value;
                    s.Aid2 = (string)dataGridView1.SelectedRows[0].Cells["id-экспоната"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
                if (table == "Стендист")
                {
                    Стендист s = new Стендист(this);
                    s.parent = this;
                    s.empty_start = false;

                    s.Aid = (string)dataGridView1.SelectedRows[0].Cells["id-стендист"].Value;
                    s.Aname = (string)dataGridView1.SelectedRows[0].Cells["ФИО"].Value;
                    s.Acomp = (string)dataGridView1.SelectedRows[0].Cells["Компания"].Value;
                    s.Adol = (string)dataGridView1.SelectedRows[0].Cells["Должность"].Value;

                    DialogResult d = s.ShowDialog();
                    if (d == DialogResult.OK)
                    {
                        PG.SendCU(tcom);
                        resize();
                        reload_view();
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if ((dataGridView1.SelectedRows.Count != 0) && (sel_id_name != ""))
                sel_id = (string)dataGridView1.SelectedRows[0].Cells[sel_id_name].Value;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
