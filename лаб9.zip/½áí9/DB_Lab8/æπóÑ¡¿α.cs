﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class Сувенир : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Aform = "";
        public string Amat = "";
        public string Atema = "";
        public string Aid2 = "";

        public Сувенир(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void сувенир_Load(object sender, EventArgs e)
        {
            textBox1.Text = Aform;
            textBox2.Text = Amat;
            textBox3.Text = Atema;
            if (Aid2 != "")
            {
                PG.PopulateFKgrid("Место проведения", dataGridView1, "id_место", Aid2);
            }
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string form = textBox1.Text;
            string mat = textBox2.Text;
            string tema = textBox3.Text;


            if ((form != "") && (mat != "") && (tema != "") && (Aid2 != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Сувенир\" " +
                        "(\"Форма\", \"Материал\", \"Тематика\", \"id_место\") " +
                        "VALUES ('" + form + "','" + mat + "','" + tema + "','" + Aid2 + "');";
                else
                    parent.tcom = "UPDATE \"Сувенир\" " +
                        "SET \"Форма\" = '" + form
                        + "', \"Материал\" = '" + mat
                        + "', \"Тематика\" = '" + tema
                        + "', \"id_место\" = '" + Aid2
                        + "' WHERE \"id-сувенир\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Место проведения";
            fk.view = true;
            fk.sel_id_name = "id_место";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Место проведения", dataGridView1, "id_место", Aid2);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
