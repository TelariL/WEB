﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class Стендист : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Adol = "";
        public string Acomp = "";
        public string Aname = "";

        public Стендист(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void стендист_Load(object sender, EventArgs e)
        {
            textBox1.Text = Aname;
            textBox2.Text = Acomp;
            textBox3.Text = Adol;
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string comp = textBox2.Text;
            string dol = textBox3.Text;


            if ((name != "") && (comp != "") && (dol != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Стендист\" " +
                        "(\"ФИО\", \"Компания\", \"Должность\") " +
                        "VALUES ('" + name + "','" + comp + "','" + dol + "');";
                else
                    parent.tcom = "UPDATE \"Стендист\" " +
                        "SET \"ФИО\" = '" + name
                        + "', \"Компания\" = '" + comp
                        + "', \"Должность\" = '" + dol
                        + "' WHERE \"id-стендист\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}
