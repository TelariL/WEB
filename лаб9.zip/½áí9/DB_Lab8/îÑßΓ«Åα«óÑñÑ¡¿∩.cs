﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class МестоПроведения : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Astrana = "";
        public string Agorod = "";
        public string Aadres = "";

        public МестоПроведения(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void местоПроведения_Load(object sender, EventArgs e)
        {
            textBox1.Text = Astrana;
            textBox2.Text = Agorod;
            textBox3.Text = Aadres;
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strana = textBox1.Text;
            string gorod = textBox2.Text;
            string adres = textBox3.Text;

            if ((strana != "") && (gorod != "") && (adres != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Место проведения\" " +
                        "(\"Страна\", \"Город\", \"Адрес\") " +
                        "VALUES ('" + strana + "','" + gorod + "','" + adres + "');";
                else
                    parent.tcom = "UPDATE \"Место проведения\" " +
                        "SET \"Страна\" = '" + strana
                        + "', \"Город\" = '" + gorod
                        + "', \"Адрес\" = '" + adres
                        + "' WHERE \"id_место\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}
