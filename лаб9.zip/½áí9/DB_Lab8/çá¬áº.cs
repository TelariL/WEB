﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab8
{
    public partial class Заказ : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Adan = "";
        public string Aid2 = "";
        public string Aid3 = "";

        public Заказ(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void заказ_Load(object sender, EventArgs e)
        {
            textBox2.Text = Adan;
            if (Aid2 != "")
            {
                PG.PopulateFKgrid("Менеджер по работе с клиентами", dataGridView3, "ФИО", Aid2);
            }
            if (Aid3 != "")
            {
                PG.PopulateFKgrid("Организация", dataGridView4, "ID организации", Aid3);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string Adan = textBox2.Text;

            if ((Adan != "") && (Aid2 != "") && (Aid3 != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Заказ\" " +
                        "(\"ID организации\", \"ФИО\", \"Данные об объекте\") " +
                        "VALUES ('" + Aid3 + "','" + Aid2 + "','" + Adan + "');";
                else
                    parent.tcom = "UPDATE \"Заказ\" " +
                        "SET \"ID организации\" = '" + Aid3
                        + "', \"ФИО\" = '" + Aid2
                        + "', \"Данные об объекте\" = '" + Adan
                        + "' WHERE \"Номер заказа\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Менеджер по работе с клиентами";
            fk.view = true;
            fk.sel_id_name = "ФИО";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Менеджер по работе с клиентами", dataGridView3, "ФИО", Aid2);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Организация";
            fk.view = true;
            fk.sel_id_name = "ID организации";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Организация", dataGridView4, "ID организации", Aid3);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Заказ_Load_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
