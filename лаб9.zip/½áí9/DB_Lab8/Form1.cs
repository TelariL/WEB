﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DB_Lab8;

namespace postgr2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PG.OpenConnection("127.0.0.1", "5432", "postgres", "1234", "Ohrana");
        }

        private void местоПроведенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Место проведения";
            g.pk_name = "id_место";
            g.Show();
        }
        private void отчетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Отчет";
            g.pk_name = "Номер отчета";
            g.pk_name2 = "ФИО";
            g.Show();
        }
        private void менеджерПоРаботеСКлиентамиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Менеджер по работе с клиентами";
            g.pk_name = "ФИО";
            g.pk_name2 = "Номер заказа";
            g.Show();
        }
        private void заказToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Заказ";
            g.pk_name = "Номер заказа";
            g.pk_name2 = "ФИО";
            g.pk_name3 = "ID организации";
            g.Show();
        }
        private void клиентToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Клиент";
            g.pk_name = "ID клиента";
            g.Show();
        }
        private void посетительToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Посетитель";
            g.pk_name = "id-посетитель";
            g.Show();
        }

        private void спонсорToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Спонсор";
            g.pk_name = "id-спонсора";
            g.Show();
        }

        private void стендToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Стенд";
            g.pk_name = "Номер стенда";
            g.pk_name2 = "id-стендиста";
            g.pk_name3 = "id-экскурсия";
            g.Show();
        }

        private void стендистToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Стендист";
            g.pk_name = "id-стендист";
            g.Show();
        }

        private void сувенирToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Сувенир";
            g.pk_name = "id-сувенир";
            g.pk_name2 = "id-место";
            g.Show();
        }

        private void экскурсияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Экскурсия";
            g.pk_name = "id-экскурсии";
            g.pk_name2 = "id-место";
            g.Show();
        }

        private void экскурсияПосетительToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "ЭкскурсияПосетитель";
            g.pk_name = "id-экскурсии";
            g.pk_name2 = "id-посетитель";
            g.Show();
        }

        private void экскурсияСпонсорToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "ЭкскурсияСпонсор";
            g.pk_name = "id-экскурсии";
            g.pk_name2 = "id-спонсор";
            g.Show();
        }

        private void экспонатСтендToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "ЭкспонатСтенд";
            g.pk_name = "Номер стенда";
            g.pk_name2 = "id-экспонат";
            g.Show();
        }

        private void экспонатToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD g = new CRUD(this);
            g.table = "Экспонат";
            g.pk_name = "id-экспонат";
            g.Show();
        }
        private void спонсорскийОтчетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD w1 = new CRUD(this);
            w1.table = "w1";
            w1.view = true;
            w1.n = (int)PG.Select_size("w1");
            w1.Show();
            this.Hide();
        }

        private void отзывыоПосещенииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD w2 = new CRUD(this);
            w2.table = "w2";
            w2.view = true;
            w2.n = (int)PG.Select_size("w2");
            w2.Show();
            this.Hide();
        }

        private void описаниеПродукцииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CRUD w3 = new CRUD(this);
            w3.table = "w3";
            w3.view = true;
            w3.n = (int)PG.Select_size("w3");
            w3.Show();
            this.Hide();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            FormAbout about = new FormAbout(this);
            about.Show();
            this.Hide();
        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
    }
}
