﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class Экскурсия : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Astoim = "";
        public string Atema = "";
        public string Adlit = "";
        public string Aid2 = "";

        public Экскурсия(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void экскурсия_Load(object sender, EventArgs e)
        {
            textBox1.Text = Astoim;
            textBox2.Text = Atema;
            textBox3.Text = Adlit;
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string stoim = textBox1.Text;
            string tema = textBox2.Text;
            string dlit = textBox3.Text;


            if ((Aid2 != "") && (stoim != "") && (tema != "") && (dlit != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Экскурсия\" " +
                        "(\"id-место\", \"Стоимость\", \"Тема\", \"Длительность\")" +
                        "VALUES ('" + Aid2 + "','" + stoim + "','" + tema + "','" + dlit + "');";
                else
                    parent.tcom = "UPDATE \"Экскурсия\" " +
                        "SET \"id-место\" = '" + Aid2
                        + "', \"Стоимость\" = '" + stoim
                        + "', \"Тема\" = '" + tema
                        + "', \"Длительность\" = '" + dlit
                        + "' WHERE \"id-экскурсии\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Место проведения";
            fk.view = true;
            fk.sel_id_name = "id-место";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("Место проведения", dataGridView1, "id-место", Aid2);
            }
        }
    }
}
