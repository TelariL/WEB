﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class Экспонат : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Aavtor = "";
        public string Amuch = "";
        public string Aname = "";

        public Экспонат(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void экспонат_Load(object sender, EventArgs e)
        {
            textBox1.Text = Aname;
            textBox2.Text = Aavtor;
            textBox3.Text = Amuch;
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string avtor = textBox2.Text;
            string much = textBox3.Text;

            if ((name != "") && (avtor != "") && (much != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Экспонат\" " +
                        "(\"название\", \"автор\", \"цена\") " +
                        "VALUES ('" + name + "','" + avtor + "','" + much + "');";
                else
                    parent.tcom = "UPDATE \"Экспонат\" " +
                        "SET \"название\" = '" + name
                        + "', \"автор\" = '" + avtor
                        + "', \"цена\" = '" + much
                        + "' WHERE \"id-экспонат\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}
