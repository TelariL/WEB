﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using postgr2;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab9
{
    public partial class ЭкспонатСтенд : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Aid2 = "";

        public ЭкспонатСтенд(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void экспонатСтенд_Load(object sender, EventArgs e)
        {
            if (Aid != "")
            {
                PG.PopulateFKgrid("Стенд", dataGridView1, "Номер стенда", Aid);
            }
            if (Aid2 != "")
            {
                PG.PopulateFKgrid("Экспонат", dataGridView2, "id-экспоната", Aid2);
            }
        }

        private void вернутьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            prevForm.Show();
            prevForm.Activate();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((Aid != "") && (Aid2 != ""))
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"ЭкспонатСтенд\" " +
                        "(\"Номер стенда\", \"id-экспоната\") " +
                        "VALUES ('" + Aid + "','" + Aid2 + "');";

                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Экспонат";
            fk.view = true;
            fk.sel_id_name = "Номер стенда";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid = fk.sel_id;
                PG.PopulateFKgrid("DetectionOfDiseases", dataGridView1, "Номер стенда", Aid);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CRUD fk = new CRUD(this);
            fk.table = "Стенд";
            fk.view = true;
            fk.sel_id_name = "id-экспоната";
            fk.ShowDialog();
            if (fk.DialogResult == DialogResult.OK)
            {
                Aid2 = fk.sel_id;
                PG.PopulateFKgrid("PatientReceptionLog", dataGridView2, "id-экспоната", Aid2);
            }
        }
    }
}
