﻿using postgr2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Lab8
{
    public partial class Клиент : Form
    {
        private Form prevForm;
        public CRUD parent;
        public bool empty_start = true;
        public string Aid = "";
        public string Afio = "";

        public Клиент(Form prevForm)
        {
            InitializeComponent();
            this.prevForm = prevForm;
        }

        private void клиент_Load(object sender, EventArgs e)
        {
            textBox1.Text = Afio;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Afio = textBox1.Text;

            if (Afio != "")
            {
                if (empty_start)
                    parent.tcom = "INSERT INTO \"Клиент\" " +
                        "(\"ФИО\") " +
                        "VALUES ('" + Afio + "');";
                else
                    parent.tcom = "UPDATE \"Клиент\" "
                        + "', \"ФИО\" = '" + Afio
                        + "' WHERE \"Номер заказа\" = '" + Aid + "';";

                DialogResult = DialogResult.OK;
                Close();
            }
        }
        
    }
}
